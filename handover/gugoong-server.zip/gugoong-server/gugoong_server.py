#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""구공이(902) 로컬 서버 — 1차 버전

이 파일 하나로 구공이 웹앱(security 폴더)을 내 PC에서 열고,
그 화면의 대화를 실제 AI에게 넘겨 준다.

    python gugoong_server.py --dry-run    # 키 없이 화면과 흐름만 확인
    python gugoong_server.py              # config.json의 키로 실제 AI 연결
    python gugoong_server.py --lan        # 같은 와이파이의 폰에서도 접속

지키는 것
  - API 키는 이 파일이 config.json(또는 환경 변수)에서만 읽고,
    화면·응답·로그 어디에도 찍지 않는다. 브라우저로 내려보내는 길 자체가 없다.
  - 외부로 나가는 요청은 config.json에 적힌 API 주소 한 곳뿐이다.
    그 밖의 링크를 열거나 따라가는 기능은 없다.
  - 대화 원문을 파일로 저장하지 않는다. 요청이 끝나면 메모리에서도 사라진다.
  - 접속 로그에는 시각·주소·응답 코드·걸린 시간만 남긴다.
    메시지 본문과 접속 IP 전체는 남기지 않는다.
  - 요청 수를 1분 단위·하루 단위로 제한한다(원칙 7).
  - 설치할 것이 없다. 파이썬 표준 라이브러리만 쓴다(3.10 이상).
"""

from __future__ import annotations

import argparse
import json
import os
import socket
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from datetime import date
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# ──────────────────────────────────────────────────────────────
# 기본값 (config.json에 없는 항목은 여기 값이 쓰인다)
# ──────────────────────────────────────────────────────────────

VERSION = "1.0.0"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "security")          # 화면 파일이 있는 폴더
CONFIG_NAME = "config.json"                              # 키가 들어가는 파일
SYSTEM_PROMPT_NAME = "system-prompt.md"                  # 구공이 성격 문서

MAX_BODY_EXTRA = 4096                # 본문 허용치에 더해 주는 여유(바이트)
MAX_UPSTREAM_BYTES = 2 * 1024 * 1024  # 제공자 응답을 읽는 최대 크기
MAX_BODY_DRAIN = 1024 * 1024          # 너무 큰 본문은 이만큼만 읽고 연결을 끊는다

DEFAULT_CONFIG = {
    # 제공자 주소. 다른 회사의 OpenAI 호환 API를 쓰려면 base_url만 바꾸면 된다.
    "base_url": "https://api.openai.com/v1",
    "chat_path": "/chat/completions",
    "api_key": "",
    # 모델 이름은 일부러 비워 둔다. 제공자 문서에서 확인한 이름을 적어야 한다.
    "model": "",
    "temperature": 0.5,
    "max_output_tokens": 500,
    "request_timeout_sec": 45,
    # 대화 기억: 마지막 몇 턴(질문+답 한 쌍)만 문맥으로 넘길지
    "max_turns": 20,
    # 한 번에 받는 메시지 길이(글자 수)
    "max_input_chars": 4000,
    # 요청 제한(원칙 7)
    "max_requests_per_minute": 10,
    "max_requests_per_day": 200,
    # 서버가 열릴 자리
    "host": "127.0.0.1",
    "port": 8787,
}

# config.json이 없거나 system-prompt.md를 못 읽었을 때 쓰는 기본 성격
DEFAULT_SYSTEM_PROMPT = """너는 "구공이(902) 보안 친구"야. 침착하고 다정한, 보안을 같이 봐 주는 경비원 친구지.
말투는 반말. 짧게. 한 번에 한 단계씩. 겁주지 않고 "괜찮아, 지금 이것만 하면 돼"라고 안내해.
사용자가 자책하면 "누구나 속을 수 있어"라고 먼저 다독여.

## 판별
- 문자·메일·링크를 받으면 위험도를 '위험 / 주의 / 확인 필요' 중 하나로 답하고, 이유를 1~2개만 붙인다.
- 절대 "안전해"라고 단정하지 않는다. 위험 신호가 없어도 '확인 필요'로 답하고 공식 앱·공식 홈페이지에서 직접 확인하도록 안내한다.
- 링크는 직접 열지 않는다. 주소 모양과 문구만 보고 판단한다.
- 판단이 서지 않으면 모른다고 말하고 KISA 118(사이버 신고), 112(경찰)로 연결한다.

## 이미 눌렀을 때
1. 먼저 그 화면을 닫도록 안내한다.
2. 있었던 일을 고르게 한다: 화면만 봤어 / 뭔가 입력했어 / 파일을 받았어 / 앱을 설치했어 / 잘 모르겠어.
3. 한 번에 하나씩 확인한다. 기종(아이폰/안드로이드)은 그 뒤에 묻는다.
4. 상황별 대처: 와이파이·데이터 끄기, 다른 기기에서 비밀번호 변경, 카드사·은행 연락, 112/KISA 118.
5. 마지막에 오늘 챙길 일을 짧게 정리하고 다독인다.

## 규칙
- 비밀번호·인증번호·카드번호·주민번호를 받지 않는다. 보내려 하면 말리며 "적지 않아도 돼"라고 한다.
- 사용자 대신 링크에 접속하지 않는다.
- 삭제·초기화·송금은 사용자가 직접 하도록 안내만 한다.
- 증거는 남긴다. 문자·메시지·링크는 지우라고 하지 않는다. "문자는 118이나 경찰에 신고할 때 증거가 되니까 지우지 말고, 열지만 마"로 안내한다.
  받은 .apk 같은 설치 파일만 열지 말고 삭제하도록 안내한다.
- 확인되지 않은 것을 안전하다고 단정하지 않는다. 놓치는 것보다 과하게 조심하는 쪽을 택한다.

## 출력 형식
- 답변은 2~4문장, 질문은 1개만.
- 첫 줄 끝에 위험도가 있으면 `[위험도: 위험]`처럼 붙인다(해당할 때만)."""


# ──────────────────────────────────────────────────────────────
# 설정 읽기
# ──────────────────────────────────────────────────────────────

def _as_int(value, default, low, high):
    """정수로 바꾸되, 이상한 값이면 기본값. 범위는 low~high로 자른다."""
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


def _as_float(value, default, low, high):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return default
    return max(low, min(high, number))


def load_config(path, dry_run=False):
    """config.json + 환경 변수를 읽어 설정을 만든다.

    돌려주는 것: (설정 dict, 문제 목록)
    문제 목록이 비어 있지 않으면 시작 전에 사람이 읽을 안내를 찍는다.
    """
    cfg = dict(DEFAULT_CONFIG)
    problems = []

    if not os.path.exists(path):
        if dry_run:
            problems.append("config.json이 아직 없어. 모의 모드라 기본값으로 열게.")
        else:
            problems.append(
                "config.json이 아직 없어. config.example.json을 config.json으로 복사한 뒤 "
                "base_url·model·api_key를 채워 줘."
            )
    else:
        try:
            with open(path, "r", encoding="utf-8-sig") as fp:
                raw = json.load(fp)
            if not isinstance(raw, dict):
                raise ValueError("맨 바깥이 { } 묶음이 아니야")
            for key, value in raw.items():
                if key in DEFAULT_CONFIG:
                    cfg[key] = value
        except (OSError, ValueError) as err:
            problems.append(f"config.json을 읽지 못했어: {err}. JSON 문법을 한 번 봐 줘.")

    # 환경 변수가 있으면 그쪽을 먼저 쓴다(키를 파일에 안 남기고 싶을 때).
    if os.environ.get("GUGOONG_API_KEY"):
        cfg["api_key"] = os.environ["GUGOONG_API_KEY"]
    if os.environ.get("GUGOONG_BASE_URL"):
        cfg["base_url"] = os.environ["GUGOONG_BASE_URL"]
    if os.environ.get("GUGOONG_MODEL"):
        cfg["model"] = os.environ["GUGOONG_MODEL"]

    cfg["api_key"] = str(cfg.get("api_key") or "").strip()
    cfg["base_url"] = str(cfg.get("base_url") or "").strip() or DEFAULT_CONFIG["base_url"]
    cfg["chat_path"] = str(cfg.get("chat_path") or "").strip() or "/chat/completions"
    cfg["model"] = str(cfg.get("model") or "").strip()
    cfg["temperature"] = _as_float(cfg.get("temperature"), 0.5, 0.0, 2.0)
    cfg["max_output_tokens"] = _as_int(cfg.get("max_output_tokens"), 500, 0, 8000)
    cfg["request_timeout_sec"] = _as_int(cfg.get("request_timeout_sec"), 45, 5, 300)
    cfg["max_turns"] = _as_int(cfg.get("max_turns"), 20, 1, 100)
    cfg["max_input_chars"] = _as_int(cfg.get("max_input_chars"), 4000, 100, 20000)
    cfg["max_requests_per_minute"] = _as_int(cfg.get("max_requests_per_minute"), 10, 0, 600)
    cfg["max_requests_per_day"] = _as_int(cfg.get("max_requests_per_day"), 200, 0, 100000)
    cfg["port"] = _as_int(cfg.get("port"), 8787, 1, 65535)
    return cfg, problems


def chat_url(cfg):
    """제공자 주소 만들기. 이 한 곳 말고는 밖으로 나가지 않는다."""
    return cfg["base_url"].rstrip("/") + "/" + cfg["chat_path"].lstrip("/")


def check_upstream_url(url):
    """주소가 안전한 모양인지 본다.

    - https만 허용. http는 이 PC 안(127.0.0.1, localhost)에서만.
      (내 PC에서 돌리는 Ollama 같은 걸 시험할 때 쓴다.)
    - 주소에 사용자 이름·비밀번호를 넣는 형태는 거부한다.
    """
    try:
        parts = urllib.parse.urlsplit(url)
    except ValueError:
        return False, "API 주소 모양이 이상해."
    if parts.scheme == "https":
        return (True, "") if parts.hostname else (False, "API 주소에 호스트 이름이 없어.")
    if parts.scheme == "http":
        if parts.hostname in ("127.0.0.1", "localhost", "::1"):
            return True, ""
        return False, "http 주소는 이 PC 안(127.0.0.1, localhost)에서만 쓸 수 있어. 밖으로는 https만."
    return False, "API 주소는 https:// 로 시작해야 해."


# ──────────────────────────────────────────────────────────────
# 키 가리기
# ──────────────────────────────────────────────────────────────

def redact(text, key):
    """혹시라도 키가 글에 섞여 나오면 '***'로 바꾼다. 마지막 안전장치."""
    if not text or not key or len(key) < 6:
        return text
    return str(text).replace(key, "***")


# ──────────────────────────────────────────────────────────────
# 성격 문서 읽기
# ──────────────────────────────────────────────────────────────

def load_system_prompt():
    """security/system-prompt.md에서 실제 프롬프트를 꺼낸다.

    그 문서는 설명 글 안에 ``` 로 감싼 프롬프트 블록을 담고 있다.
    블록이 있으면 블록 안만, 없으면 문서 전체를 쓴다.
    파일이 없거나 비었으면 내장 기본값을 쓴다.
    """
    path = os.path.join(STATIC_DIR, SYSTEM_PROMPT_NAME)
    try:
        with open(path, "r", encoding="utf-8-sig") as fp:
            text = fp.read()
    except OSError:
        return DEFAULT_SYSTEM_PROMPT

    if "```" in text:
        parts = text.split("```")
        if len(parts) >= 3 and parts[1].strip():
            block = parts[1]
            # 첫 줄이 ```python 같은 언어 표시면 떼어 낸다
            first_line, _, rest = block.partition("\n")
            if first_line.strip() and " " not in first_line.strip() and len(first_line) < 20 and rest:
                block = rest
            if block.strip():
                return block.strip()

    text = text.strip()
    return text or DEFAULT_SYSTEM_PROMPT


# ──────────────────────────────────────────────────────────────
# 요청 수 제한 (원칙 7)
# ──────────────────────────────────────────────────────────────

class RateLimiter:
    """같은 IP에서 온 요청을 1분·하루 단위로 센다.

    메모리에만 세므로 서버를 다시 켜면 0부터 시작한다.
    """

    def __init__(self, per_minute, per_day):
        self.per_minute = per_minute
        self.per_day = per_day
        self.lock = threading.Lock()
        self.minute = {}   # ip -> deque(요청 시각들, 최근 1분)
        self.day = {}      # ip -> [날짜 문자열, 오늘 횟수]

    def check(self, ip):
        """(허용 여부, 기다릴 초, 막은 이유)를 돌려준다."""
        now = time.time()
        today = date.today().isoformat()
        with self.lock:
            hits = self.minute.setdefault(ip, deque())
            while hits and now - hits[0] > 60:
                hits.popleft()

            if self.per_minute and len(hits) >= self.per_minute:
                wait = int(60 - (now - hits[0])) + 1
                return False, max(1, wait), "minute"

            record = self.day.get(ip)
            if record is None or record[0] != today:
                record = [today, 0]
                self.day[ip] = record
            if self.per_day and record[1] >= self.per_day:
                return False, 0, "day"

            hits.append(now)
            record[1] += 1
            self._prune(today)
            return True, 0, ""

    def _prune(self, today):
        """오래된 흔적을 지워 메모리가 계속 커지지 않게 한다."""
        if len(self.minute) > 2000:
            for key in [k for k, v in self.minute.items() if not v]:
                del self.minute[key]
        if len(self.day) > 2000:
            for key in [k for k, v in self.day.items() if v[0] != today]:
                del self.day[key]

    def today_total(self):
        today = date.today().isoformat()
        with self.lock:
            return sum(v[1] for v in self.day.values() if v[0] == today)

    def today_for(self, ip):
        today = date.today().isoformat()
        with self.lock:
            record = self.day.get(ip)
            return record[1] if record and record[0] == today else 0


# ──────────────────────────────────────────────────────────────
# 제공자 호출 (OpenAI 호환 Chat Completions)
# ──────────────────────────────────────────────────────────────

def _pick_reply_text(payload):
    """제공자 응답에서 답변 글자만 꺼낸다."""
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices:
        return None
    first = choices[0]
    if not isinstance(first, dict):
        return None
    message = first.get("message")
    if not isinstance(message, dict):
        return None
    content = message.get("content")
    if isinstance(content, str):
        return content.strip() or None
    if isinstance(content, list):  # 일부 제공자는 조각 목록으로 준다
        pieces = []
        for part in content:
            if isinstance(part, dict) and isinstance(part.get("text"), str):
                pieces.append(part["text"])
            elif isinstance(part, str):
                pieces.append(part)
        joined = "".join(pieces).strip()
        return joined or None
    return None


def call_upstream(cfg, messages, key):
    """제공자에게 대화를 보내고 답을 받는다.

    돌려주는 것: (성공 여부, 코드, 답변 또는 안내 문구)
    코드는 'ok' / 'timeout' / 'network' / 'auth' / 'rate' / 'request' / 'upstream' 중 하나.
    """
    url = chat_url(cfg)
    ready, why = check_upstream_url(url)
    if not ready:
        return False, "config", why

    body = {"model": cfg["model"], "messages": messages}
    if cfg["temperature"] is not None:
        body["temperature"] = cfg["temperature"]
    if cfg["max_output_tokens"]:
        body["max_tokens"] = cfg["max_output_tokens"]

    data = json.dumps(body, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(url, data=data, method="POST")
    request.add_header("Content-Type", "application/json")
    request.add_header("Accept", "application/json")
    request.add_header("Authorization", "Bearer " + key)
    request.add_header("User-Agent", "GugoongServer/" + VERSION)

    try:
        with urllib.request.urlopen(request, timeout=cfg["request_timeout_sec"]) as response:
            raw = response.read(MAX_UPSTREAM_BYTES)
    except urllib.error.HTTPError as error:
        detail = ""
        try:
            detail = error.read(2000).decode("utf-8", "replace")
        except Exception:  # noqa: BLE001 - 읽기 실패는 무시하고 상태 코드만 쓴다
            detail = ""
        detail = redact(_shorten(detail, 300), key)
        if detail:
            print("  ※ 제공자 응답: " + detail.replace("\n", " "))
        if error.code in (401, 403):
            return False, "auth", "키가 맞지 않는 것 같아. config.json의 api_key를 한 번 확인해 줘."
        if error.code == 429:
            return False, "rate", "제공자 쪽에서 잠깐 요청이 많다고 해. 조금 뒤에 다시 물어봐 줘."
        if error.code in (400, 404, 422):
            return False, "request", (
                "요청 형식이나 모델 이름이 제공자와 맞지 않는 것 같아. "
                "config.json의 model·base_url을 확인해 줘."
            )
        return False, "upstream", "AI 쪽에 잠깐 문제가 생겼어. 조금 뒤에 다시 불러 줘."
    except (socket.timeout, TimeoutError):
        return False, "timeout", "AI가 답을 늦게 주고 있어. 잠깐 뒤에 다시 물어봐 줘."
    except urllib.error.URLError as error:
        reason = getattr(error, "reason", error)
        if isinstance(reason, (socket.timeout, TimeoutError)):
            return False, "timeout", "AI가 답을 늦게 주고 있어. 잠깐 뒤에 다시 물어봐 줘."
        print("  ※ 연결 실패: " + redact(str(reason), key))
        return False, "network", "AI 쪽에 닿지 못했어. 인터넷 연결을 한 번 봐 줘."
    except Exception as error:  # noqa: BLE001 - 어떤 이유든 화면은 다정하게
        print("  ※ 예상 밖 오류: " + redact(str(error), key))
        return False, "network", "AI 쪽에 닿지 못했어. 잠깐 뒤에 다시 불러 줘."

    try:
        payload = json.loads(raw.decode("utf-8", "replace"))
    except ValueError:
        return False, "upstream", "AI가 보낸 답을 읽지 못했어. 조금 뒤에 다시 불러 줘."

    reply = _pick_reply_text(payload)
    if not reply:
        return False, "upstream", "AI가 빈 답을 보냈어. 조금 뒤에 다시 물어봐 줘."
    return True, "ok", reply


def _shorten(text, limit):
    text = str(text)
    return text if len(text) <= limit else text[:limit] + "…"


def mock_reply(messages):
    """--dry-run에서 쓰는 모의 답. 실제 AI는 부르지 않는다."""
    last_user = ""
    for message in reversed(messages):
        if message.get("role") == "user":
            last_user = message.get("content", "")
            break
    preview = _shorten(last_user.replace("\n", " "), 60)
    return (
        "모의 응답이야. 아직 실제 AI를 부르지 않고, 서버를 거쳐 답이 오는 길만 확인하는 중이야.\n\n"
        f"내가 받은 말: \"{preview}\"\n\n"
        "이 화면에 '연결됨(모의)' 배지가 보이면 서버는 제대로 돌고 있어. "
        "config.json에 키와 모델 이름을 넣고 다시 열면 진짜 구공이가 답해."
    )


# ──────────────────────────────────────────────────────────────
# 화면 파일 내보내기
# ──────────────────────────────────────────────────────────────

MIME_TYPES = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "text/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
    ".md": "text/plain; charset=utf-8",
    ".txt": "text/plain; charset=utf-8",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".svg": "image/svg+xml",
    ".ico": "image/x-icon",
    ".woff2": "font/woff2",
}


def safe_static_path(url_path):
    """주소를 실제 파일 경로로 바꾼다. security 폴더 밖으로는 절대 못 나간다."""
    if not url_path or url_path == "/":
        url_path = "/index.html"
    if "\x00" in url_path:
        return None
    decoded = urllib.parse.unquote(url_path)
    relative = decoded.lstrip("/")
    if not relative or ".." in relative.split("/"):
        return None
    full = os.path.normpath(os.path.join(STATIC_DIR, relative))
    root = os.path.normpath(STATIC_DIR) + os.sep
    if not full.startswith(root):
        return None
    if os.path.isdir(full):
        return None
    return full


# ──────────────────────────────────────────────────────────────
# 요청 처리
# ──────────────────────────────────────────────────────────────

class GugoongHandler(BaseHTTPRequestHandler):
    server_version = "GugoongServer/" + VERSION
    sys_version = ""
    protocol_version = "HTTP/1.1"
    timeout = 60  # 놀고 있는 연결은 스스로 닫는다

    # ----- 공통 도구 -----

    def log_message(self, fmt, *args):
        # 파이썬 기본 로그는 접속 IP와 요청 원문을 그대로 남긴다.
        # 원칙 8에 따라 쓰지 않고, 아래 _log에서 시각·코드·시간만 남긴다.
        return

    def _log(self, status, started, note=""):
        spent = int((time.time() - started) * 1000)
        stamp = time.strftime("%H:%M:%S")
        extra = f" {note}" if note else ""
        print(f"[{stamp}] {self.command} {self._path_only()} -> {status} ({spent}ms){extra}")

    def _path_only(self):
        """주소에서 ? 뒤를 떼고 경로만 남긴다(로그에 검색어 등을 남기지 않는다)."""
        try:
            return urllib.parse.urlsplit(self.path).path or "/"
        except ValueError:
            return "/"

    def _send(self, status, body, content_type, started, extra_headers=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        for name, value in (extra_headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass
        self._log(status, started)

    def _json(self, status, payload, started, extra_headers=None):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self._send(status, body, "application/json; charset=utf-8", started, extra_headers)

    def _text(self, status, text, started):
        self._send(status, text.encode("utf-8"), "text/plain; charset=utf-8", started)

    def _cfg(self):
        return self.server.cfg  # type: ignore[attr-defined]

    # ----- GET -----

    def do_GET(self):
        started = time.time()
        path = self._path_only()
        if path == "/api/health":
            return self._health(started)
        if path.startswith("/api/"):
            return self._json(404, {
                "ok": False, "code": "not_found",
                "message": "그런 주소는 없어. 화면은 http://127.0.0.1:%d/ 에 있어." % self._cfg()["port"],
            }, started)
        return self._static(started)

    def do_HEAD(self):
        return self.do_GET()

    def _health(self, started):
        cfg = self._cfg()
        key_ready = bool(cfg["api_key"]) and bool(cfg["model"])
        self._json(200, {
            "ok": True,
            "service": "gugoong-server",
            "version": VERSION,
            "ai": bool(key_ready and not self.server.dry_run),   # type: ignore[attr-defined]
            "mock": bool(self.server.dry_run),                   # type: ignore[attr-defined]
            "model": cfg["model"],
            "limits": {
                "per_minute": cfg["max_requests_per_minute"],
                "per_day": cfg["max_requests_per_day"],
                "max_turns": cfg["max_turns"],
                "max_input_chars": cfg["max_input_chars"],
            },
            "requests_today": self.server.limiter.today_total(),  # type: ignore[attr-defined]
            "uptime_sec": int(time.time() - self.server.started_at),  # type: ignore[attr-defined]
        }, started)

    def _static(self, started):
        path = self._path_only()
        full = safe_static_path(path)
        if full is None:
            return self._text(404, "그런 파일은 없어. 주소를 한 번 확인해 줘.", started)
        ext = os.path.splitext(full)[1].lower()
        if ext not in MIME_TYPES:
            return self._text(403, "이 종류의 파일은 내보내지 않아.", started)
        try:
            with open(full, "rb") as fp:
                body = fp.read()
        except FileNotFoundError:
            if path in ("/", "/index.html"):
                return self._text(500, "화면 파일(security/index.html)을 찾지 못했어. "
                                       "이 프로그램과 같은 폴더에 security 폴더가 있어야 해.", started)
            return self._text(404, "그런 파일은 없어.", started)
        except OSError:
            return self._text(500, "파일을 읽지 못했어.", started)
        headers = {"Cache-Control": "no-cache"} if ext in (".html", ".css", ".js") else None
        self._send(200, body, MIME_TYPES[ext], started, headers)

    # ----- POST -----

    def do_POST(self):
        started = time.time()
        if self._path_only() != "/api/chat":
            self.close_connection = True
            return self._json(404, {
                "ok": False, "code": "not_found",
                "message": "그런 주소는 없어. 대화는 /api/chat 으로만 받아.",
            }, started)

        cfg = self._cfg()

        # 1) 다른 사이트에서 몰래 부르는 요청을 막는다.
        origin = self.headers.get("Origin")
        if origin and origin not in self.server.allowed_origins:  # type: ignore[attr-defined]
            self.close_connection = True
            return self._json(403, {
                "ok": False, "code": "origin",
                "message": "이 화면에서 온 요청이 아니라서 막았어.",
            }, started)

        # 2) JSON으로 온 요청만 받는다(브라우저 폼으로는 못 보내게).
        content_type = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
        if content_type not in ("application/json", "text/json", ""):
            self.close_connection = True
            return self._json(415, {
                "ok": False, "code": "content_type",
                "message": "application/json 으로 보내 줘.",
            }, started)

        if (self.headers.get("Transfer-Encoding") or "").lower() == "chunked":
            self.close_connection = True
            return self._json(411, {
                "ok": False, "code": "length",
                "message": "Content-Length를 붙여서 보내 줘.",
            }, started)

        # 3) 본문 길이 확인
        limit_bytes = cfg["max_input_chars"] * 4 + MAX_BODY_EXTRA
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            self.close_connection = True
            return self._json(400, {
                "ok": False, "code": "length",
                "message": "본문 길이를 읽지 못했어.",
            }, started)

        if length <= 0:
            self.close_connection = True
            return self._json(400, {
                "ok": False, "code": "empty",
                "message": "보낼 대화가 비어 있어.",
            }, started)

        if length > limit_bytes:
            self._drain(length)
            self.close_connection = True
            return self._json(413, {
                "ok": False, "code": "too_long",
                "message": "보낸 글이 너무 길어. 이름·주소는 가리고, 수상한 부분만 잘라서 붙여넣어 줘.",
            }, started)

        try:
            raw = self.rfile.read(length)
        except (OSError, ValueError):
            self.close_connection = True
            return self._json(400, {"ok": False, "code": "read", "message": "본문을 읽지 못했어."}, started)

        # 4) JSON 해석
        try:
            data = json.loads(raw.decode("utf-8", "replace"))
        except ValueError:
            return self._json(400, {
                "ok": False, "code": "json",
                "message": "보낸 글이 JSON 형식이 아니야.",
            }, started)
        if not isinstance(data, dict):
            return self._json(400, {
                "ok": False, "code": "json",
                "message": "보낸 글이 JSON 형식이 아니야.",
            }, started)

        messages, problem = self._clean_messages(data.get("messages"), cfg["max_input_chars"], cfg["max_turns"])
        if problem:
            return self._json(400, {"ok": False, "code": "messages", "message": problem}, started)

        # 5) 요청 수 제한 (원칙 7)
        client = self.client_address[0]
        allowed, wait, why = self.server.limiter.check(client)  # type: ignore[attr-defined]
        if not allowed:
            if why == "minute":
                message = (f"잠깐 숨 고르고 다시 와 줄래? 1분에 {cfg['max_requests_per_minute']}번까지 "
                           f"이야기할 수 있어. {wait}초 뒤에 다시 불러 줘.")
            else:
                message = (f"오늘은 여기까지 이야기했어. 하루에 {cfg['max_requests_per_day']}번까지 "
                           "이야기할 수 있어. 내일 다시 불러 주면 이어서 볼게.")
            return self._json(429, {
                "ok": False, "code": "rate_limit", "reason": why,
                "retry_after": wait, "message": message,
            }, started, {"Retry-After": str(wait)} if wait else None)

        # 6) 모의 모드
        if self.server.dry_run:  # type: ignore[attr-defined]
            return self._json(200, {"ok": True, "reply": mock_reply(messages), "mock": True}, started)

        # 7) 키·모델 확인 (키 값은 절대 화면으로 보내지 않는다)
        if not cfg["api_key"]:
            return self._json(503, {
                "ok": False, "code": "no_key",
                "message": "키가 아직 없어. 이 PC의 config.json에 api_key를 넣어 줘. 키는 나한테 보내지 않아도 돼.",
            }, started)
        if not cfg["model"]:
            return self._json(503, {
                "ok": False, "code": "no_model",
                "message": "모델 이름이 아직 비어 있어. config.json의 model에 제공자 문서에서 본 이름을 적어 줘.",
            }, started)

        # 8) 제공자 호출 — 성격 문서를 첫 시스템 메시지로 넣는다
        full = [{"role": "system", "content": load_system_prompt()}] + messages
        ok, code, result = call_upstream(cfg, full, cfg["api_key"])
        if not ok:
            status = {"timeout": 504, "network": 502, "auth": 502, "rate": 429,
                      "request": 502, "config": 500}.get(code, 502)
            payload = {"ok": False, "code": code, "message": result}
            if code == "rate":
                payload["retry_after"] = 20
            return self._json(status, payload, started)
        return self._json(200, {"ok": True, "reply": result, "mock": False}, started)

    def _drain(self, length):
        """읽지 않은 본문을 조금만 버려서 연결이 엉키지 않게 한다."""
        left = min(length, MAX_BODY_DRAIN)
        try:
            while left > 0:
                chunk = self.rfile.read(min(65536, left))
                if not chunk:
                    break
                left -= len(chunk)
        except (OSError, ValueError):
            return

    def _clean_messages(self, raw, max_input_chars, max_turns):
        """브라우저가 보낸 대화를 검사하고 필요한 만큼만 남긴다."""
        if not isinstance(raw, list) or not raw:
            return None, "보낼 대화가 비어 있어."
        clean = []
        for item in raw:
            if not isinstance(item, dict):
                continue
            role = item.get("role")
            content = item.get("content")
            if role not in ("user", "assistant") or not isinstance(content, str):
                continue
            content = content.strip()
            if not content:
                continue
            if len(content) > max_input_chars:
                content = content[:max_input_chars]
            clean.append({"role": role, "content": content})
        if not any(m["role"] == "user" for m in clean):
            return None, "보낼 대화가 비어 있어."
        # 마지막 몇 턴만 문맥으로 쓴다 (원칙 8: 기록은 필요한 만큼만)
        return clean[-max_turns * 2:], ""


# ──────────────────────────────────────────────────────────────
# 서버 준비와 실행
# ──────────────────────────────────────────────────────────────

class GugoongServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler, cfg, dry_run):
        self.cfg = cfg
        self.dry_run = dry_run
        self.limiter = RateLimiter(cfg["max_requests_per_minute"], cfg["max_requests_per_day"])
        self.started_at = time.time()
        self.allowed_origins = build_origins(cfg["port"], address[0])
        super().__init__(address, handler)


def local_ips():
    """이 PC의 내부 IP 후보를 찾는다(폰에서 접속할 주소를 알려 주려고)."""
    found = []
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = info[4][0]
            if not ip.startswith("127.") and ip not in found:
                found.append(ip)
    except OSError:
        pass
    if not found:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            probe.connect(("8.8.8.8", 80))  # 실제로 보내지는 않고 경로만 확인한다
            ip = probe.getsockname()[0]
            if ip and ip not in ("0.0.0.0", "127.0.0.1"):
                found.append(ip)
        except OSError:
            pass
        finally:
            probe.close()
    return found


def build_origins(port, host):
    """이 서버 화면에서 온 요청으로 인정할 주소 목록.

    같은 와이파이의 폰이 PC 이름(예: DESKTOP-ABC:8787)으로 들어올 수도 있어서
    이 PC의 이름도 함께 넣는다. 남의 도메인은 절대 넣지 않는다.
    """
    origins = {
        f"http://127.0.0.1:{port}",
        f"http://localhost:{port}",
    }
    try:
        name = socket.gethostname().strip().lower()
        if name:
            origins.add(f"http://{name}:{port}")
            origins.add(f"http://{name}.local:{port}")
    except OSError:
        pass
    if host == "0.0.0.0":
        for ip in local_ips():
            origins.add(f"http://{ip}:{port}")
    return origins


def already_running(port):
    """그 자리에 이미 구공이 서버가 떠 있는지 살펴본다(내 PC 안에서만)."""
    url = f"http://127.0.0.1:{port}/api/health"
    try:
        with urllib.request.urlopen(url, timeout=1.5) as response:
            info = json.loads(response.read(4096).decode("utf-8", "replace"))
        return bool(isinstance(info, dict) and info.get("service") == "gugoong-server")
    except (urllib.error.URLError, ValueError, OSError):
        return False


def parse_args(argv=None):
    parser = argparse.ArgumentParser(
        description="구공이(902) 로컬 서버 — 웹앱과 실제 AI를 이 PC에서 이어 준다.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "예시:\n"
            "  python gugoong_server.py --dry-run     키 없이 화면·흐름 확인\n"
            "  python gugoong_server.py               실제 AI 연결\n"
            "  python gugoong_server.py --lan         같은 와이파이의 폰에서도 접속\n"
        ),
    )
    parser.add_argument("--lan", action="store_true",
                        help="같은 와이파이의 폰에서 접속할 수 있게 연다(공용 와이파이에서는 쓰지 말 것)")
    parser.add_argument("--port", type=int, default=None, help="포트 번호(기본 8787)")
    parser.add_argument("--config", default=os.path.join(BASE_DIR, CONFIG_NAME),
                        help="설정 파일 경로(기본 같은 폴더의 config.json)")
    parser.add_argument("--dry-run", action="store_true",
                        help="키 없이 모의 응답으로 화면과 흐름만 확인")
    parser.add_argument("--version", action="store_true", help="버전만 보여 주고 끝낸다")
    return parser.parse_args(argv)


def print_banner(cfg, host, port, dry_run, problems):
    line = "─" * 58
    print(line)
    print(f" 구공이(902) 로컬 서버 v{VERSION}")
    print(line)

    if dry_run:
        print(" 모드: 모의(--dry-run) — 실제 AI를 부르지 않고 흐름만 확인해.")
    elif not cfg["api_key"]:
        print(" 모드: 키 없음 — 화면은 열리지만 대화는 안내 문구만 돌려줄게.")
    elif not cfg["model"]:
        print(" 모드: 모델 이름 없음 — config.json의 model을 채워 줘.")
    else:
        print(f" 모드: 실제 AI 연결 · 모델 {cfg['model']}")
        print(f" 주소: {chat_url(cfg)}")

    print(f" 화면: http://127.0.0.1:{port}/")
    if host == "0.0.0.0":
        ips = local_ips()
        print("")
        print(" ⚠ 같은 와이파이에서만 열려 있어. 공용 와이파이(카페·공항)에서는 켜지 마.")
        if ips:
            for ip in ips:
                print(f"   폰에서 열 주소: http://{ip}:{port}/")
        else:
            print("   폰에서 열 주소: (이 PC의 내부 IP를 찾지 못했어. ipconfig로 확인해 줘)")
        print("   외부 인터넷으로는 열지 않아(포트포워딩·터널 없음).")

    print(f" 제한: 1분 {cfg['max_requests_per_minute']}번 · 하루 {cfg['max_requests_per_day']}번 · "
          f"문맥 {cfg['max_turns']}턴 · 입력 {cfg['max_input_chars']}자")
    print(" 기록: 대화 원문은 저장하지 않아. 로그에는 시각·응답 코드·걸린 시간만 남겨.")
    print(" 키: 화면·로그에 절대 찍지 않아.")
    print(line)
    if problems:
        for problem in problems:
            print(" · " + problem)
        print(line)
    print(" 멈추려면 Ctrl+C")
    print("")


def main(argv=None):
    # 콘솔에서 한글이 깨지지 않고, 안내가 바로바로 보이게
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace", line_buffering=True)  # type: ignore[attr-defined]
    except (AttributeError, ValueError):
        pass

    args = parse_args(argv)
    if args.version:
        print(f"gugoong-server {VERSION}")
        return 0

    cfg, problems = load_config(args.config, args.dry_run)
    if args.port:
        cfg["port"] = _as_int(args.port, cfg["port"], 1, 65535)

    fatal = [p for p in problems if "config.json" in p and "복사" in p]
    if fatal and not args.dry_run:
        for problem in problems:
            print(" · " + problem)
        print("\n설정이 없어서 시작하지 않았어. --dry-run 으로 화면부터 확인해 봐도 좋아.")
        return 1

    if not os.path.isdir(STATIC_DIR):
        print(f"화면 폴더를 찾지 못했어: {STATIC_DIR}")
        print("이 프로그램과 같은 위치에 security 폴더가 있어야 해.")
        return 1

    host = "0.0.0.0" if args.lan else "127.0.0.1"
    port = cfg["port"]

    if already_running(port):
        print(f"이미 구공이 서버가 {port}번에서 돌고 있어. 브라우저에서 이 주소를 열어 봐.")
        print(f"  화면: http://127.0.0.1:{port}/")
        print("새로 켜려면 먼저 그 창에서 Ctrl+C로 끄거나, --port 8788 처럼 다른 번호를 써 줘.")
        return 0

    try:
        server = GugoongServer((host, port), GugoongHandler, cfg, args.dry_run)
    except OSError as error:
        print(f"{port}번 자리를 열지 못했어: {error}")
        print(f"이미 다른 프로그램이 쓰고 있을 수 있어. --port {port + 1} 처럼 다른 번호로 열어 봐.")
        return 1

    print_banner(cfg, host, port, args.dry_run, problems)

    try:
        server.serve_forever(poll_interval=0.3)
    except KeyboardInterrupt:
        print("\n구공이 서버를 닫을게. 오늘도 이상한 문자 없이 조용히 지나가자.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
