#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""구공이 PC 검사기 (1차 데모)

구공이(902)는 "침착하고 다정한 경비원 친구"예요.
이 프로그램은 바이러스 검사 엔진을 직접 만들지 않습니다.
윈도우에 이미 들어 있는 '윈도우 보안(마이크로소프트 디펜더)'의
검증된 엔진을 명령줄(MpCmdRun.exe)로 빌려 쓰고,
구공이는 ① 검사 실행을 도와주고 ② 결과를 다정하게 설명하는 역할만 합니다.
어설픈 자체 엔진이 "괜찮아요"라고 잘못 안심시키는 것이 가장 위험하기 때문입니다.

실행 예시
--------
    python gugoong_pc.py                 # 메뉴 (관리자 권한 권장)
    python gugoong_pc.py --quick         # 빠른 검사
    python gugoong_pc.py --full          # 전체 검사
    python gugoong_pc.py --folder "C:\\Users\\me\\Downloads"
    python gugoong_pc.py --status        # 상태 점검만 (관리자 권한 없이도 시도)
    python gugoong_pc.py --update        # 바이러스 사전 업데이트
    python gugoong_pc.py --dry-run       # 화면 예시만 출력 (리눅스/맥에서도 됨)

지키는 원칙
----------
1. API 키나 계정 정보를 코드에 저장하지 않습니다. (이 프로그램은 키가 필요 없습니다.)
2. 의심스러운 링크에 스스로 접속하지 않습니다. (네트워크 요청을 하지 않습니다.)
3. 개인정보를 모으거나 저장하지 않습니다. 화면에는 폴더 이름 정도만 보여 줍니다.
4. 확실하지 않은 것을 단정하지 않습니다. "안전해" 대신 "지금은 발견된 게 없어"라고 말합니다.
5. 질문은 한 번에 하나만 합니다.
6. 위험한 상황에서는 행동 지침을 먼저 보여 줍니다.
7. 사용량 제한을 두지 않습니다(디펜더는 공짜, 횟수 제한 없음). 검사 시간만 안내합니다.
8. 기록을 남기지 않습니다. 결과를 파일로 저장하지 않습니다.

하지 않는 일
----------
- 파일을 직접 지우거나 격리하지 않습니다. (필요하면 디펜더가 처리합니다.)
- 사용자 파일을 어디로도 올리거나 보내지 않습니다.
- 관리자 권한을 강제로 올리지 않습니다. (UAC를 띄우지 않고, 안내만 합니다.)
- 레지스트리/설정을 바꾸지 않습니다. (상태를 읽기만 합니다.)

이 파일은 표준 라이브러리만 사용합니다. 외부 패키지 설치가 필요 없습니다.
파이썬 3.10 이상에서 돌아갑니다.
"""

from __future__ import annotations

import argparse
import ctypes
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timedelta

APP_NAME = "구공이 PC 검사기"
VERSION = "0.1.0"
IS_WINDOWS = (os.name == "nt")

QUICK, FULL, CUSTOM = 1, 2, 3
SCAN_LABELS = {QUICK: "빠른 검사", FULL: "전체 검사", CUSTOM: "폴더 검사"}
# 검사 종류별 최대 대기 시간(초). 넘으면 검사를 멈추고 알려 줍니다.
SCAN_TIMEOUTS = {QUICK: 60 * 60, FULL: 4 * 60 * 60, CUSTOM: 2 * 60 * 60}

# 상태 점검에서 읽어 온 디펜더 서비스 버전. MpCmdRun.exe 경로를 고를 때 힌트로 씁니다.
_service_version_hint = None


# ─────────────────────────────────────────────────────────────
# 화면 출력 도우미
# ─────────────────────────────────────────────────────────────

def say(text="") -> None:
    """한 줄 출력. 콘솔이 표현하지 못하는 글자(이모지 등)는 '?'로 바꿔서라도 출력한다."""
    try:
        print(text)
    except UnicodeEncodeError:
        enc = sys.stdout.encoding or "ascii"
        print(str(text).encode(enc, "replace").decode(enc, "replace"))


def rule(title=None) -> None:
    say()
    if title:
        say(title)
    say("-" * 52)


def setup_console() -> None:
    """윈도우 콘솔에서 한글·이모지가 깨지지 않도록 UTF-8로 맞춘다."""
    if IS_WINDOWS:
        try:
            kernel32 = ctypes.windll.kernel32
            kernel32.SetConsoleOutputCP(65001)
            kernel32.SetConsoleCP(65001)
        except Exception:
            pass
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


def banner() -> None:
    say()
    say("   /\\_/\\")
    say("  ( o.o )   " + APP_NAME)
    say("   > ^ <    v" + VERSION + " · 1차 데모")


def greet() -> None:
    banner()
    say()
    say("안녕, 나는 구공이야. 네 PC를 같이 살펴보는 경비원 친구.")
    say("내가 바이러스를 직접 잡지는 않아. 윈도우에 이미 들어 있는")
    say("'윈도우 보안(디펜더)'한테 검사를 부탁하고, 결과를 네가")
    say("알아듣기 쉽게 풀어서 알려 줄게.")


def farewell() -> None:
    say()
    say("오늘도 수고했어. 이상한 게 보이면 언제든 다시 불러 줘.")
    say("나는 여기 있을게. 🐾")


def wait_before_close() -> None:
    """탐색기에서 두 번 눌러 실행했을 때 결과를 보고 창을 닫을 수 있게 한다."""
    if not sys.stdin.isatty():
        return
    try:
        input("\nEnter를 누르면 창이 닫혀.")
    except (EOFError, KeyboardInterrupt):
        pass


# ─────────────────────────────────────────────────────────────
# 윈도우 / 권한 확인
# ─────────────────────────────────────────────────────────────

def is_admin() -> bool:
    if not IS_WINDOWS:
        return False
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def not_windows_text() -> None:
    say()
    say("지금 이 컴퓨터는 윈도우가 아니야.")
    say("구공이 PC 검사기는 윈도우 노트북에서만 진짜 검사를 할 수 있어.")
    say("윈도우에서 쓰는 방법은 README.md에 정리해 뒀어.")
    say()
    say("화면이 어떻게 나오는지 미리 보려면 이렇게 해 봐:")
    say("  python gugoong_pc.py --dry-run")


def admin_need_text() -> None:
    say()
    say("이건 관리자 권한이 있어야 해.")
    say("창을 닫고 이렇게 다시 열어 줘:")
    say("  1) 시작 메뉴에서 'PowerShell'을 검색해.")
    say("  2) 'Windows PowerShell'을 오른쪽 클릭 → '관리자 권한으로 실행'")
    say("  3) 이 파일이 있는 폴더로 이동한 다음:  python gugoong_pc.py")
    say()
    say("프로그램이 권한을 대신 올려 주지는 않아. 네가 직접 여는 게 맞아.")
    say("지금은 '4번 내 PC 상태 점검'만 해 볼 수 있어.")


def admin_short_note() -> None:
    say()
    say("(안내) 지금은 관리자 권한 없이 열렸어. 검사는 관리자 권한이 있어야 돌아가.")
    say("       상태 점검(4번)은 지금도 해 볼 수 있어.")


# ─────────────────────────────────────────────────────────────
# MpCmdRun.exe 찾기
# ─────────────────────────────────────────────────────────────

def _version_tuple(name: str):
    parts = re.findall(r"\d+", name)
    return tuple(int(p) for p in parts) if parts else (0,)


def find_mpcmdrun():
    """윈도우 보안의 검사 도구(MpCmdRun.exe)를 찾는다. 없으면 None.

    우선순위:
      1) %ProgramData%\\Microsoft\\Windows Defender\\Platform\\<최신 버전>\\MpCmdRun.exe
         (마이크로소프트 문서: 최신 버전은 항상 Platform 폴더에 있다)
      2) %ProgramFiles%\\Windows Defender\\MpCmdRun.exe
      3) PATH에 있는 MpCmdRun.exe
    상태 점검에서 읽은 AMServiceVersion이 있으면 그 버전 폴더를 먼저 본다.
    """
    candidates = []

    program_data = os.environ.get("ProgramData", r"C:\ProgramData")
    platform_root = os.path.join(program_data, "Microsoft", "Windows Defender", "Platform")
    ranked = []
    try:
        for name in os.listdir(platform_root):
            exe = os.path.join(platform_root, name, "MpCmdRun.exe")
            if os.path.isfile(exe):
                ranked.append((_version_tuple(name), name, exe))
    except OSError:
        pass

    ranked.sort(key=lambda row: (row[0], row[1]), reverse=True)
    if _service_version_hint:
        preferred = [row for row in ranked if row[1].startswith(str(_service_version_hint))]
        ranked = preferred + [row for row in ranked if row not in preferred]
    candidates.extend(row[2] for row in ranked)

    program_files = os.environ.get("ProgramFiles", r"C:\Program Files")
    candidates.append(os.path.join(program_files, "Windows Defender", "MpCmdRun.exe"))

    found = shutil.which("MpCmdRun.exe")
    if found:
        candidates.append(found)

    for path in candidates:
        try:
            if os.path.isfile(path):
                return path
        except OSError:
            continue
    return None


def mp_not_found_text() -> None:
    say()
    say("윈도우 보안(디펜더)의 검사 도구를 찾지 못했어.")
    say("이런 경우가 있어:")
    say("  - 윈도우 보안이 꺼져 있다")
    say("  - 다른 백신 프로그램이 대신 맡고 있어서 디펜더가 쉬고 있다")
    say("  - 아주 오래된 윈도우다")
    say()
    say("확인하는 법: 시작 → 'Windows 보안' 검색 → '바이러스 및 위협 방지'")
    say("거기서 '빠른 검사'를 직접 눌러도 같은 엔진으로 검사돼.")
    say("구공이는 그 결과를 같이 읽어 줄 수 있어.")


# ─────────────────────────────────────────────────────────────
# PowerShell 실행 (상태 읽기용)
# ─────────────────────────────────────────────────────────────

STATUS_BODY = r"""
        function FmtDate($value) {
            if ($null -eq $value) { return $null }
            try { return ([datetime]$value).ToString('yyyy-MM-dd HH:mm:ss') } catch { return $null }
        }
        function BoolOrNull($value) {
            if ($null -eq $value) { return $null }
            try { return [bool]$value } catch { return $null }
        }
        function IntOrNull($value) {
            if ($null -eq $value) { return $null }
            try { return [int]$value } catch { return $null }
        }

        $st = Get-MpComputerStatus -ErrorAction Stop
        $prefs = $null
        try { $prefs = Get-MpPreference -ErrorAction Stop } catch { }

        $threats = @()
        $threatsRead = $false
        try {
            $meta = @{}
            try {
                foreach ($t in @(Get-MpThreat -ErrorAction Stop)) {
                    $meta[[string]$t.ThreatID] = $t
                }
            } catch { }
            $detections = @(Get-MpThreatDetection -ErrorAction Stop |
                            Sort-Object InitialDetectionTime -Descending |
                            Select-Object -First 10)
            $threatsRead = $true
            foreach ($d in $detections) {
                $tid = [string]$d.ThreatID
                $nm = ''
                $active = $null
                if ($meta.ContainsKey($tid)) {
                    $nm = [string]$meta[$tid].ThreatName
                    $active = (BoolOrNull $meta[$tid].IsActive)
                }
                $threats += [pscustomobject]@{
                    time = (FmtDate $d.InitialDetectionTime)
                    name = $nm
                    threat_id = $tid
                    action_success = (BoolOrNull $d.ActionSuccess)
                    still_active = $active
                }
            }
        } catch { }

        $fw = @()
        try {
            foreach ($p in @(Get-NetFirewallProfile -ErrorAction Stop)) {
                $fw += [pscustomobject]@{ name = [string]$p.Name; enabled = (BoolOrNull $p.Enabled) }
            }
        } catch { }

        $avs = @()
        try {
            foreach ($a in @(Get-CimInstance -Namespace 'root/SecurityCenter2' -ClassName AntivirusProduct -ErrorAction Stop)) {
                $avs += [string]$a.displayName
            }
        } catch { }

        $maps = $null
        if ($prefs -ne $null -and $prefs.PSObject.Properties.Name -contains 'MAPSReporting') {
            $maps = (IntOrNull $prefs.MAPSReporting)
        }
        $tamper = $null
        if ($st.PSObject.Properties.Name -contains 'IsTamperProtected') {
            $tamper = (BoolOrNull $st.IsTamperProtected)
        }
        $mode = $null
        if ($st.PSObject.Properties.Name -contains 'AMRunningMode') {
            $mode = [string]$st.AMRunningMode
        }

        [pscustomobject]@{
            antimalware_enabled = (BoolOrNull $st.AntivirusEnabled)
            realtime            = (BoolOrNull $st.RealTimeProtectionEnabled)
            cloud_maps          = $maps
            signature_version   = [string]$st.AntivirusSignatureVersion
            signature_age       = (IntOrNull $st.AntivirusSignatureAge)
            signature_updated   = (FmtDate $st.AntivirusSignatureLastUpdated)
            engine_version      = [string]$st.AMEngineVersion
            service_version     = [string]$st.AMServiceVersion
            running_mode        = $mode
            tamper              = $tamper
            quick_end           = (FmtDate $st.QuickScanEndTime)
            full_end            = (FmtDate $st.FullScanEndTime)
            threats             = @($threats)
            threats_read        = $threatsRead
            firewall            = @($fw)
            av_products         = @($avs)
        }
"""

RECENT_DETECTION_BODY = r"""
        function FmtDate($value) {
            if ($null -eq $value) { return $null }
            try { return ([datetime]$value).ToString('yyyy-MM-dd HH:mm:ss') } catch { return $null }
        }
        function BoolOrNull($value) {
            if ($null -eq $value) { return $null }
            try { return [bool]$value } catch { return $null }
        }

        $since = [datetime]::ParseExact('{since}', 'yyyy-MM-dd HH:mm:ss', $null)
        $meta = @{}
        try {
            foreach ($t in @(Get-MpThreat -ErrorAction Stop)) {
                $meta[[string]$t.ThreatID] = $t
            }
        } catch { }
        $rows = @()
        $detections = @(Get-MpThreatDetection -ErrorAction Stop |
                        Where-Object { $_.InitialDetectionTime -ge $since } |
                        Sort-Object InitialDetectionTime -Descending |
                        Select-Object -First 5)
        foreach ($d in $detections) {
            $tid = [string]$d.ThreatID
            $nm = ''
            $active = $null
            if ($meta.ContainsKey($tid)) {
                $nm = [string]$meta[$tid].ThreatName
                $active = (BoolOrNull $meta[$tid].IsActive)
            }
            $rows += [pscustomobject]@{
                time = (FmtDate $d.InitialDetectionTime)
                name = $nm
                threat_id = $tid
                action_success = (BoolOrNull $d.ActionSuccess)
                still_active = $active
            }
        }
        [pscustomobject]@{ threats = @($rows) }
"""


def _powershell_exe() -> str:
    system_root = os.environ.get("SystemRoot", r"C:\Windows")
    path = os.path.join(system_root, "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
    if os.path.isfile(path):
        return path
    return shutil.which("powershell") or "powershell"


def run_powershell_json(body: str, timeout: int = 90):
    """PowerShell 스크립트를 돌려 JSON 결과를 받는다.

    돌려주는 값: (data, error)
      data  : 스크립트가 돌려준 dict (실패하면 None)
      error : 사람이 읽을 수 있는 짧은 오류 설명 (성공하면 None)

    결과는 임시 폴더의 파일로 받는다. 콘솔 인코딩(cp949/UTF-8) 문제를 피하려는 것이다.
    임시 파일은 성공/실패와 상관없이 지운다.
    """
    if not IS_WINDOWS:
        return None, "윈도우에서만 실행할 수 있어"

    tmpdir = tempfile.mkdtemp(prefix="gugoong-")
    script_path = os.path.join(tmpdir, "check.ps1")
    out_path = os.path.join(tmpdir, "result.json")
    script = (
        "$ErrorActionPreference = 'Stop'\n"
        "$ProgressPreference = 'SilentlyContinue'\n"
        "try {\n"
        "  $data = & {\n"
        + body +
        "\n  }\n"
        "  $payload = [pscustomobject]@{ ok = $true; data = $data }\n"
        "} catch {\n"
        "  $payload = [pscustomobject]@{ ok = $false; error = [string]$_.Exception.Message }\n"
        "}\n"
        "$payload | ConvertTo-Json -Depth 8 -Compress | Set-Content -LiteralPath $env:GUGOONG_OUT -Encoding UTF8\n"
    )

    try:
        try:
            with open(script_path, "w", encoding="utf-8-sig", newline="\n") as fh:
                fh.write(script)
            env = os.environ.copy()
            env["GUGOONG_OUT"] = out_path
            flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            completed = subprocess.run(
                [_powershell_exe(), "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                 "-File", script_path],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                timeout=timeout, env=env, creationflags=flags,
            )
        except subprocess.TimeoutExpired:
            return None, "상태를 읽는 데 시간이 너무 오래 걸려서 멈췄어"
        except OSError as exc:
            return None, "PowerShell을 실행하지 못했어: " + _short(str(exc))

        try:
            if not os.path.isfile(out_path):
                detail = _decode_bytes(completed.stderr or b"")
                return None, "PowerShell이 결과를 남기지 않았어" + ((": " + _short(detail)) if detail.strip() else "")
            with open(out_path, "r", encoding="utf-8-sig") as fh:
                raw = fh.read()
            payload = json.loads(raw)
        except (OSError, ValueError) as exc:
            return None, "결과를 읽지 못했어: " + _short(str(exc))
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    if not isinstance(payload, dict):
        return None, "결과 형식이 예상과 달라"
    if not payload.get("ok"):
        return None, _short(str(payload.get("error") or "알 수 없는 오류"))

    data = payload.get("data")
    if isinstance(data, list) and len(data) == 1:
        data = data[0]
    if not isinstance(data, dict):
        return None, "읽어 온 내용이 비어 있어"
    return data, None


def _decode_bytes(raw: bytes) -> str:
    for encoding in ("utf-8", "cp949", "mbcs", "latin-1"):
        try:
            return raw.decode(encoding)
        except (UnicodeDecodeError, LookupError):
            continue
    return raw.decode("utf-8", "replace")


def _short(text: str, limit: int = 200) -> str:
    text = re.sub(r"\s+", " ", str(text or "")).strip()
    # 화면에 사용자 폴더 경로가 그대로 나오지 않게 가린다.
    text = re.sub(r"([A-Za-z]:\\Users\\)[^\\\s]+", r"\1<사용자>", text)
    return text if len(text) <= limit else text[: limit - 1] + "…"


# ─────────────────────────────────────────────────────────────
# 날짜 / 값 해석 도우미
# ─────────────────────────────────────────────────────────────

_DT_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?")
_DATE_EPOCH_RE = re.compile(r"/Date\((\d+)(?:[+-]\d{4})?\)/")


def parse_dt(value):
    """PowerShell이 보낸 날짜 문자열을 datetime으로. 못 읽거나 의미 없는 값이면 None."""
    if not isinstance(value, str):
        return None
    text = value.strip()
    match = _DT_RE.match(text)
    if match:
        try:
            parsed = datetime(
                int(match.group(1)), int(match.group(2)), int(match.group(3)),
                int(match.group(4)), int(match.group(5)), int(match.group(6) or 0),
            )
        except ValueError:
            return None
        # 윈도우가 "아직 없음"을 1601-01-01 같은 기본값으로 줄 때가 있다.
        return parsed if parsed.year >= 2000 else None
    match = _DATE_EPOCH_RE.search(text)
    if match:
        try:
            parsed = datetime.fromtimestamp(int(match.group(1)) / 1000.0)
        except (ValueError, OSError, OverflowError):
            return None
        return parsed if parsed.year >= 2000 else None
    return None


def fmt_when(dt) -> str:
    return dt.strftime("%Y-%m-%d %H:%M") if dt else "시각 모름"


def days_ago(dt) -> str:
    if not dt:
        return ""
    days = (datetime.now() - dt).days
    if days <= 0:
        return "오늘"
    if days == 1:
        return "어제"
    return "{}일 전".format(days)


def human_duration(seconds: float) -> str:
    seconds = int(max(0, seconds))
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    if hours:
        return "{}시간 {}분".format(hours, minutes)
    if minutes:
        return "{}분 {}초".format(minutes, secs)
    return "{}초".format(secs)


def _as_list(value):
    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [value]


def _onoff(value, on_text, off_text, unknown_text):
    if value is True:
        return on_text
    if value is False:
        return off_text
    return unknown_text


def action_phrase(threat) -> str:
    """위협 기록 하나의 '조치 상태'를 사실대로 짧게."""
    if threat.get("still_active") is True:
        return "아직 남아 있을 수 있어 — 확인 필요"
    success = threat.get("action_success")
    if success is True:
        return "디펜더가 조치했어"
    if success is False:
        return "조치가 끝나지 않았어 — 확인 필요"
    return "상태는 확인 못 했어"


# ─────────────────────────────────────────────────────────────
# 상태 점검
# ─────────────────────────────────────────────────────────────

def collect_status():
    global _service_version_hint
    data, error = run_powershell_json(STATUS_BODY, timeout=120)
    if data:
        hint = data.get("service_version")
        if isinstance(hint, str) and hint.strip():
            _service_version_hint = hint.strip()
    return data, error


def render_status(data) -> None:
    rule("내 PC 상태 점검")

    say("  - 디펜더(백신): " + _onoff(data.get("antimalware_enabled"), "켜져 있어", "꺼져 있어", "확인 못 했어"))
    say("  - 실시간 보호: " + _onoff(data.get("realtime"), "켜져 있어", "꺼져 있어", "확인 못 했어"))

    maps = data.get("cloud_maps")
    if maps == 2:
        cloud = "켜져 있어 (고급)"
    elif maps == 1:
        cloud = "기본으로만 켜져 있어"
    elif maps == 0:
        cloud = "꺼져 있어"
    else:
        cloud = "확인 못 했어"
    say("  - 클라우드 보호: " + cloud)

    version = str(data.get("signature_version") or "").strip() or "버전 확인 못 함"
    updated = parse_dt(data.get("signature_updated"))
    age = data.get("signature_age")
    line = "  - 바이러스 사전: " + version
    if updated:
        line += " · " + fmt_when(updated) + "에 받았어"
    if isinstance(age, int):
        if age >= 65535:
            line += " · 아직 한 번도 업데이트가 안 된 것 같아"
        elif age <= 1:
            line += " · 최신이야"
        else:
            line += " · {}일 지났어".format(age)
    say(line)

    quick = parse_dt(data.get("quick_end"))
    full = parse_dt(data.get("full_end"))
    say("  - 마지막 빠른 검사: " + ("{} ({})".format(fmt_when(quick), days_ago(quick)) if quick else "기록이 없어"))
    say("  - 마지막 전체 검사: " + ("{} ({})".format(fmt_when(full), days_ago(full)) if full else "기록이 없어"))

    firewalls = _as_list(data.get("firewall"))
    if firewalls:
        names = {"Domain": "도메인", "Private": "개인", "Public": "공용"}
        on_names = [names.get(item.get("name"), item.get("name") or "?") for item in firewalls if item.get("enabled")]
        off_names = [names.get(item.get("name"), item.get("name") or "?") for item in firewalls if not item.get("enabled")]
        if not off_names:
            say("  - 방화벽: 켜져 있어 (" + "·".join(on_names) + ")")
        elif not on_names:
            say("  - 방화벽: 꺼져 있어")
        else:
            say("  - 방화벽: 일부만 켜져 있어 — 꺼진 곳: " + ", ".join(off_names))
    else:
        say("  - 방화벽: 확인 못 했어")

    tamper = data.get("tamper")
    if tamper is not None:
        say("  - 변조 방지: " + _onoff(tamper, "켜져 있어", "꺼져 있어", "확인 못 했어"))

    mode = data.get("running_mode")
    if isinstance(mode, str) and mode.strip() and mode.strip().lower() != "normal":
        say("  - 디펜더 모드: {} (다른 보안 프로그램과 같이 도는 중일 수 있어)".format(mode.strip()))

    products = [str(p) for p in _as_list(data.get("av_products")) if str(p).strip()]
    if products:
        say("  - 이 PC에 등록된 백신: " + ", ".join(products))

    say()
    say("최근 위협 기록")
    threats = _as_list(data.get("threats"))
    if not threats:
        if data.get("threats_read") is False:
            say("  - 지금은 기록을 읽지 못했어. 'Windows 보안 → 보호 기록'에서 직접 볼 수 있어.")
        else:
            say("  - 최근에 걸린 기록은 없어.")
    else:
        for threat in threats[:3]:
            when = parse_dt(threat.get("time"))
            name = str(threat.get("name") or "").strip() or "이름은 확인 못 했어"
            say("  - {} · {} · {}".format(fmt_when(when), name, action_phrase(threat)))
        if len(threats) > 3:
            say("  - (이전 기록이 더 있어. 자세한 건 '보호 기록'에서 볼 수 있어.)")

    say()
    tips = []
    if data.get("antimalware_enabled") is False:
        tips.append("디펜더가 꺼져 있어. 켜 두는 걸 추천해. (Windows 보안 → 바이러스 및 위협 방지)")
    if data.get("realtime") is False:
        tips.append("실시간 보호가 꺼져 있어. 새 파일을 열 때 지켜 주는 기능이라 켜 두는 게 좋아. "
                    "(Windows 보안 → 바이러스 및 위협 방지 → 설정 관리)")
    if isinstance(age, int) and 3 <= age < 65535:
        tips.append("바이러스 사전이 {}일 전 거야. 메뉴 5번(사전 업데이트)으로 새로 받자.".format(age))
    if not quick and not full:
        tips.append("검사 기록이 거의 없어. 메뉴 1번(빠른 검사)부터 한 번 돌려 보자.")
    if firewalls and any(not item.get("enabled") for item in firewalls):
        tips.append("방화벽이 꺼진 프로필이 있어. 인터넷을 쓸 때는 켜 두는 게 좋아.")
    if tamper is False:
        tips.append("변조 방지가 꺼져 있어. Windows 보안에 이 설정이 있으면 켜 두는 게 좋아. "
                    "보안 설정을 마음대로 못 바꾸게 막아 주는 기능이야. "
                    "(Windows 보안 → 바이러스 및 위협 방지 → 설정 관리)")
    if isinstance(mode, str) and mode.strip().lower() not in ("", "normal"):
        tips.append("지금 디펜더는 다른 보안 프로그램과 같이 도는 중이야. 그 프로그램이 최신인지 확인해 줘.")
    if data.get("threats_read") is False:
        tips.append("최근 위협 기록을 읽지 못했어. 'Windows 보안 → 보호 기록'에서 직접 확인해 줘.")

    if tips:
        say("챙기면 좋은 것")
        for tip in tips:
            say("  · " + tip)
        say()
        say("위에 적은 것만 챙기면 돼. 나머지는 지금 설정대로 돌아가고 있어.")
    else:
        say("지금은 설정에서 눈에 띄는 문제가 없어.")
        say("다만 이건 '지금 이 순간'의 상태라서, 새로 받은 파일이나 링크는 열기 전에 한 번 더 보는 게 좋아.")
    say()
    say("(이 점검은 읽기만 했어. 아무것도 바꾸지 않았어.)")


def render_status_unavailable(error) -> None:
    say()
    say("지금은 윈도우 보안(디펜더) 상태를 읽지 못했어.")
    say("이유는 보통 이런 것들이야:")
    say("  - 윈도우 보안이 꺼져 있다")
    say("  - 다른 백신 프로그램이 대신 맡고 있다")
    say("  - 관리자 권한이 없어 접근이 막혔다")
    say()
    say("확인하는 법: 시작 → 'Windows 보안' 검색 → '바이러스 및 위협 방지'")
    say("거기서 '실시간 보호'가 켜져 있는지 봐 줘.")
    say("다른 백신을 쓰고 있다면, 그 백신이 최신인지만 확인하면 돼.")
    if error:
        say()
        say("(기술 메모: " + _short(error, 160) + ")")


def do_status() -> None:
    say()
    say("PC 상태를 읽어 올게. 잠깐만 기다려 줘.")
    data, error = collect_status()
    if data is None:
        render_status_unavailable(error)
        return
    render_status(data)


# ─────────────────────────────────────────────────────────────
# 검사 실행
# ─────────────────────────────────────────────────────────────

def _run_streaming(cmd, timeout):
    """명령을 돌리면서 '아직 하는 중'을 알려 준다.

    돌려주는 값: (code, elapsed, status, output_bytes)
      status: done | timeout | cancelled | spawn_error
    """
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            creationflags=flags,
        )
    except OSError as exc:
        return None, 0.0, "spawn_error", str(exc).encode("utf-8", "replace")

    chunks = []

    def _reader(pipe):
        try:
            for line in iter(pipe.readline, b""):
                chunks.append(line)
        except Exception:
            pass
        finally:
            try:
                pipe.close()
            except Exception:
                pass

    reader = threading.Thread(target=_reader, args=(proc.stdout,), daemon=True)
    reader.start()

    start = time.monotonic()
    next_tick = 20.0
    try:
        while proc.poll() is None:
            elapsed = time.monotonic() - start
            if elapsed > timeout:
                proc.kill()
                try:
                    proc.wait(timeout=10)
                except Exception:
                    pass
                reader.join(timeout=2)
                return None, elapsed, "timeout", b"".join(chunks)
            if elapsed >= next_tick:
                say("  ... 아직 하는 중이야 ({} 지났어)".format(human_duration(elapsed)))
                next_tick += 20.0 if elapsed < 120 else 60.0
            time.sleep(1.0)
    except KeyboardInterrupt:
        try:
            proc.kill()
            proc.wait(timeout=10)
        except Exception:
            pass
        reader.join(timeout=2)
        return None, time.monotonic() - start, "cancelled", b"".join(chunks)

    reader.join(timeout=3)
    return proc.returncode, time.monotonic() - start, "done", b"".join(chunks)


def explain_mp_error(code) -> str:
    if code is None:
        return ""
    unsigned = int(code) & 0xFFFFFFFF
    table = {
        0x800106BA: "윈도우 보안(디펜더) 서비스가 꺼져 있어서 검사를 못 했어.",
        0x80070005: "관리자 권한이 없어서 검사를 못 했어.",
        0x80070002: "검사할 경로를 찾지 못했어. 경로를 다시 확인해 줘.",
        0x80004005: "검사 중에 알 수 없는 문제가 생겼어.",
        0x8050800C: "검사에 넘긴 경로에 문제가 있었어. 폴더 경로를 다시 확인해 줘.",
        0x80508018: "검사가 중간에 취소됐어.",
        0x80508022: "검사를 마치려면 PC를 다시 시작해야 할 수 있어.",
    }
    return table.get(unsigned, "")


def _cancel_defender_scan(mp) -> None:
    """멈춘 뒤 디펜더 쪽에 남아 있는 검사가 있으면 취소를 시도한다.

    MpCmdRun을 종료해도 백신 서비스의 검사가 계속 도는 경우가 있어서
    `-Cancel`을 한 번 보낸다. 실패해도 조용히 넘어간다(사용자에게 실패를 떠넘기지 않음).
    """
    try:
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.run(
            [mp, "-Cancel"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=15,
            creationflags=flags,
        )
    except Exception:
        pass


def get_recent_detections(since) -> tuple:
    """검사 시작 시각 이후에 잡힌 위협 기록을 읽는다. (list, error) — 읽기 실패면 ([], error)."""
    body = RECENT_DETECTION_BODY.replace("{since}", since.strftime("%Y-%m-%d %H:%M:%S"))
    data, error = run_powershell_json(body, timeout=60)
    if data is None:
        return [], error
    return _as_list(data.get("threats")), None


def _scan_target_label(scan_type, target):
    if scan_type != CUSTOM:
        return SCAN_LABELS[scan_type]
    name = os.path.basename(os.path.normpath(target)) if target else ""
    return "{} ('{}')".format(SCAN_LABELS[CUSTOM], name or "고른 폴더")


def do_scan(scan_type, target=None):
    """검사 실행 + 결과 안내. 프로그램 종료 코드를 돌려준다(0 정상, 2 조치 필요)."""
    mp = find_mpcmdrun()
    if not mp:
        mp_not_found_text()
        return 1

    if scan_type == CUSTOM and target:
        try:
            target = os.path.abspath(target)
        except Exception:
            pass

    label = _scan_target_label(scan_type, target)
    cmd = [mp, "-Scan", "-ScanType", str(scan_type)]
    if scan_type == CUSTOM:
        cmd += ["-File", target]

    started = datetime.now()
    say()
    if scan_type == QUICK:
        say("빠른 검사를 시작할게. 보통 2~10분 걸려.")
    elif scan_type == FULL:
        say("전체 검사를 시작할게. 한 시간, 길면 몇 시간 걸릴 수도 있어.")
    else:
        say("'{}' 폴더만 검사할게.".format(os.path.basename(os.path.normpath(target)) or target))
    say("검사 중에는 이 창을 닫지 말고 기다려 줘. 멈추고 싶으면 Ctrl+C를 눌러도 돼.")

    code, elapsed, status, output = _run_streaming(cmd, SCAN_TIMEOUTS.get(scan_type, 2 * 60 * 60))

    if status == "cancelled":
        _cancel_defender_scan(mp)
        say()
        say("검사는 중간에 멈췄어. 이미 살펴본 곳에서 걸린 게 있으면")
        say("디펜더가 그때 처리했을 수 있어.")
        say("다시 하고 싶으면 같은 메뉴를 한 번 더 골라 줘.")
        return 1

    if status == "timeout":
        _cancel_defender_scan(mp)
        say()
        say("검사가 너무 오래 걸려서 여기서 멈췄어. ({} 지남)".format(human_duration(elapsed)))
        say("PC가 느리거나 파일이 아주 많으면 그럴 수 있어.")
        say("'폴더 하나만 검사'로 나눠서 해 보는 것도 좋아.")
        return 1

    if status == "spawn_error":
        say()
        say("검사 도구를 실행하지 못했어.")
        say("(기술 메모: " + _short(_decode_bytes(output), 160) + ")")
        say("관리자 권한으로 다시 열어서 한 번 더 해 봐.")
        return 1

    detections = []
    detection_checked = False
    if code in (0, 2):
        found, _err = get_recent_detections(started - timedelta(minutes=2))
        detection_checked = _err is None
        detections = found

    render_scan_result(label, code, elapsed, detections, detection_checked)
    if code == 0:
        return 0
    if code == 2:
        return 2
    return 1


def render_scan_result(label, code, elapsed, detections, detection_checked) -> None:
    rule(label + " 결과")
    say("  걸린 시간: " + human_duration(elapsed))
    say()

    if code == 0:
        if not detection_checked:
            say("검사는 끝까지 돌았어.")
            say("디펜더가 알려 준 건 '지금 처리할 게 남아 있지 않다'야.")
            say("(발견된 게 있었는지는 '윈도우 보안 → 보호 기록'에서 볼 수 있어.)")
        elif detections:
            say("검사 중에 걸린 항목이 기록에 남아 있어.")
            say()
            _print_detections(detections)
            say()
            if all(threat.get("action_success") is True for threat in detections):
                say("디펜더가 조치를 마쳤다고 나와 있어. 자세한 건 '보호 기록'에서 볼 수 있어.")
            else:
                say("조치가 끝났는지는 '보호 기록'에서 확인해 줘.")
        else:
            say("이번 검사에서는 걸린 게 없었어.")
        say()
        say("이 결과는 이번에 검사한 곳에서 나온 거야.")
        say("새로 받은 파일이 있으면, 그 파일이 있는 폴더만 3번으로 한 번 더 검사해 보자.")
        return

    if code == 2:
        say("디펜더가 '아직 처리할 게 남아 있다'고 알려 줬어.")
        say("(검사 중에 오류가 있었을 때도 이 코드가 나와.)")
        say("이게 꼭 나쁜 뜻은 아니야. 격리를 해 두고 네 확인을 기다리는 경우도 많아.")
        say()
        if detections:
            say("디펜더가 잡은 항목:")
            _print_detections(detections)
            say()
        say("확인하는 곳: 시작 → 'Windows 보안' → '보호 기록'")
        say("  · '격리됨'이면 이미 따로 치워 둔 거야. 그대로 두면 돼.")
        say("  · '허용됨'이면 네가 직접 판단한 거야. 기억이 안 나면 파일 이름을 확인해 봐.")
        say("  · 모르는 파일이면 '제거'를 고르면 돼.")
        say("  · 뭘 골라야 할지 모르겠으면, 그 화면을 캡처해서")
        say("    구공이 웹앱(security)에 보여 줘. 같이 볼게.")
        return

    say("검사가 끝까지 가지 못했어.")
    hint = explain_mp_error(code)
    if hint:
        say(hint)
    say()
    say("이렇게 해 봐:")
    say("  1) 관리자 권한으로 창을 다시 열어서 한 번 더")
    say("  2) '내 PC 상태 점검'(4번)으로 윈도우 보안이 켜져 있는지 확인")
    say("  3) 계속 같은 오류면 이 화면을 캡처해서 클로드 코드나 챗GPT에게 보여 줘")
    if code is not None:
        say()
        say("(오류 코드: {:#010x})".format(int(code) & 0xFFFFFFFF))


def _print_detections(detections) -> None:
    for threat in detections[:3]:
        when = parse_dt(threat.get("time"))
        name = str(threat.get("name") or "").strip() or "이름은 확인 못 했어"
        prefix = fmt_when(when) + " · " if when else ""
        say("  · " + prefix + name)
        say("    → " + action_phrase(threat))


def do_signature_update() -> int:
    mp = find_mpcmdrun()
    if not mp:
        mp_not_found_text()
        return 1

    say()
    say("바이러스 사전을 새로 받아 볼게. 인터넷에 연결돼 있어야 해.")
    say("1~3분쯤 걸릴 수 있어.")
    code, elapsed, status, output = _run_streaming([mp, "-SignatureUpdate"], 15 * 60)

    if status == "cancelled":
        say()
        say("사전 업데이트를 중간에 멈췄어. 다시 하고 싶으면 메뉴에서 한 번 더 골라 줘.")
        return 1
    if status == "timeout":
        say()
        say("사전 업데이트가 너무 오래 걸려서 멈췄어. 인터넷 연결을 확인하고 다시 해 봐.")
        return 1
    if status == "spawn_error":
        say()
        say("업데이트 도구를 실행하지 못했어. 관리자 권한으로 다시 열어 줘.")
        return 1

    say()
    say("  걸린 시간: " + human_duration(elapsed))
    if code == 0:
        say("사전 업데이트를 마쳤어.")
        say("'4번 내 PC 상태 점검'에서 새 버전과 날짜를 확인할 수 있어.")
        return 0

    hint = explain_mp_error(code)
    say("사전 업데이트가 끝까지 가지 못했어.")
    if hint:
        say(hint)
    say("인터넷 연결을 확인하고, 관리자 권한으로 다시 해 봐.")
    say("(오류 코드: {:#010x})".format(int(code) & 0xFFFFFFFF))
    return 1


# ─────────────────────────────────────────────────────────────
# 메뉴
# ─────────────────────────────────────────────────────────────

def show_menu(admin_user: bool) -> None:
    rule("무엇을 할까?")
    say("  1. 빠른 검사          (자주 쓰는 곳만 훑어. 몇 분)")
    say("  2. 전체 검사          (구석구석. 오래 걸려)")
    say("  3. 폴더 하나만 검사   (받은 파일이 있는 곳만)")
    say("  4. 내 PC 상태 점검    (보호 설정·최근 기록·방화벽)")
    say("  5. 바이러스 사전 업데이트")
    say("  6. 도움말")
    say("  q. 끝내기")
    if not admin_user:
        say()
        say("(지금은 관리자 권한이 없어서 1·2·3·5번은 안 돼. 4번은 해 볼 수 있어.)")
    rule()


def pick(prompt: str) -> str:
    try:
        return input(prompt).strip()
    except (EOFError, KeyboardInterrupt):
        say()
        return "q"


def pause() -> None:
    try:
        input("\nEnter를 누르면 메뉴로 돌아갈게.")
    except (EOFError, KeyboardInterrupt):
        pass


def normalize_path(raw: str):
    text = (raw or "").strip().strip('"').strip("'").strip()
    if not text:
        return None
    text = os.path.expandvars(os.path.expanduser(text))
    return text


def ask_folder_and_scan() -> int:
    raw = pick("검사할 폴더 경로를 붙여넣어 줘: ")
    path = normalize_path(raw)
    if not path:
        say("경로가 비어 있어. 폴더를 열고 주소창 내용을 복사해서 붙여넣어 봐.")
        return 1
    if not os.path.exists(path):
        say("그 경로를 찾지 못했어. 폴더를 열어서 주소창 내용을 그대로 복사해 붙여넣어 봐.")
        say("(예: C:\\Users\\내이름\\Downloads)")
        return 1
    if not (os.path.isdir(path) or os.path.isfile(path)):
        say("그건 폴더도 파일도 아니야. 다시 확인해 줘.")
        return 1
    return do_scan(CUSTOM, path)


def print_help() -> None:
    rule("도움말")
    say("구공이는 윈도우 보안(디펜더)의 검사 엔진을 빌려 써.")
    say()
    say("  1번 빠른 검사: 자주 쓰는 폴더와 시작 프로그램 쪽을 몇 분 안에 봐.")
    say("  2번 전체 검사: 모든 드라이브를 봐. 오래 걸리니까 시간 넉넉할 때.")
    say("  3번 폴더 검사: 받은 파일이 있는 폴더만 콕 집어 봐. 제일 자주 쓰게 될 거야.")
    say("  4번 상태 점검: 실시간 보호, 사전 날짜, 최근 위협 기록, 방화벽을 읽어.")
    say("  5번 사전 업데이트: 새로 나온 바이러스 목록을 받아 와.")
    say()
    say("알아 둘 것:")
    say("  · 검사는 관리자 권한이 있어야 해. 프로그램이 대신 권한을 올리지는 않아.")
    say("  · 구공이는 파일을 지우거나 격리하지 않아. 필요하면 디펜더가 처리해.")
    say("  · 검사 결과가 '발견된 게 없어'여도, 그건 이번에 검사한 범위 얘기야.")
    say("  · 결과를 어디로 보내지 않고, 기록도 남기지 않아.")
    say()
    say("윈도우 밖에서 화면만 보려면:  python gugoong_pc.py --dry-run")


def menu_loop(admin_user: bool) -> None:
    while True:
        say()
        show_menu(admin_user)
        choice = pick("번호를 골라 줘 (q는 끝내기): ")
        lowered = choice.lower()

        if lowered in ("q", "quit", "exit", "끝", "그만", "그만할래"):
            farewell()
            return

        if choice == "1":
            if not admin_user:
                admin_need_text()
                pause()
                continue
            do_scan(QUICK)
            pause()
        elif choice == "2":
            if not admin_user:
                admin_need_text()
                pause()
                continue
            say()
            say("전체 검사는 한 시간, 길면 몇 시간 걸릴 수도 있어.")
            answer = pick("그래도 지금 할까? (y/N): ").lower()
            if answer not in ("y", "yes", "ㅇ", "응", "네", "어"):
                say("알겠어. 시간 넉넉할 때 하자.")
                continue
            do_scan(FULL)
            pause()
        elif choice == "3":
            if not admin_user:
                admin_need_text()
                pause()
                continue
            ask_folder_and_scan()
            pause()
        elif choice == "4":
            do_status()
            pause()
        elif choice == "5":
            if not admin_user:
                admin_need_text()
                pause()
                continue
            do_signature_update()
            pause()
        elif choice == "6":
            print_help()
            pause()
        else:
            say("1~6 또는 q 중에서 골라 줘.")


# ─────────────────────────────────────────────────────────────
# 명령줄 인자
# ─────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="gugoong_pc.py",
        description="구공이 PC 검사기 — 윈도우 보안(디펜더)을 빌려 쓰는 검사 도우미 (1차 데모)",
        add_help=True,
    )
    parser.add_argument("--quick", action="store_true", help="빠른 검사 (ScanType 1)")
    parser.add_argument("--full", action="store_true", help="전체 검사 (ScanType 2)")
    parser.add_argument("--folder", metavar="PATH", help="폴더/파일 하나만 검사 (ScanType 3)")
    parser.add_argument("--status", action="store_true", help="PC 상태 점검만 하기")
    parser.add_argument("--update", action="store_true", help="바이러스 사전 업데이트")
    parser.add_argument("--dry-run", action="store_true", help="실제 검사 없이 화면 예시만 보기 (리눅스/맥에서도 됨)")
    parser.add_argument("--no-pause", action="store_true", help="끝나고 Enter를 기다리지 않기")
    parser.add_argument("--version", action="store_true", help="버전만 보기")
    return parser


def run_cli(args, admin_user: bool) -> int:
    if args.status:
        do_status()
        return 0

    if args.update:
        if not admin_user:
            admin_need_text()
            return 3
        return do_signature_update()

    scan_type = QUICK if args.quick else FULL if args.full else CUSTOM if args.folder is not None else None
    if scan_type is None:
        return 1

    if not admin_user:
        admin_need_text()
        return 3

    target = None
    if scan_type == CUSTOM:
        target = normalize_path(args.folder)
        if not target:
            say("검사할 경로가 비어 있어.")
            return 1
        if not os.path.exists(target):
            say("그 경로를 찾지 못했어. 경로를 다시 확인해 줘.")
            return 1

    return do_scan(scan_type, target)


# ─────────────────────────────────────────────────────────────
# 화면 예시 (--dry-run)
# ─────────────────────────────────────────────────────────────

def _dry_status_ok():
    now = datetime.now()
    return {
        "antimalware_enabled": True,
        "realtime": True,
        "cloud_maps": 2,
        "signature_version": "1.429.12.0",
        "signature_age": 0,
        "signature_updated": (now - timedelta(hours=3)).strftime("%Y-%m-%d %H:%M:%S"),
        "engine_version": "1.1.26100.1",
        "service_version": "4.18.25010.7",
        "running_mode": "Normal",
        "tamper": True,
        "quick_end": (now - timedelta(days=2)).strftime("%Y-%m-%d %H:%M:%S"),
        "full_end": None,
        "threats": [],
        "threats_read": True,
        "firewall": [
            {"name": "Domain", "enabled": True},
            {"name": "Private", "enabled": True},
            {"name": "Public", "enabled": True},
        ],
        "av_products": [],
    }


def _dry_status_issues():
    now = datetime.now()
    return {
        "antimalware_enabled": True,
        "realtime": False,
        "cloud_maps": 1,
        "signature_version": "1.421.3.0",
        "signature_age": 9,
        "signature_updated": (now - timedelta(days=9)).strftime("%Y-%m-%d %H:%M:%S"),
        "engine_version": "1.1.25080.5",
        "service_version": "4.18.25010.7",
        "running_mode": "Normal",
        "tamper": False,
        "quick_end": (now - timedelta(days=16)).strftime("%Y-%m-%d %H:%M:%S"),
        "full_end": None,
        "threats": [
            {
                "time": (now - timedelta(days=4)).strftime("%Y-%m-%d %H:%M:%S"),
                "name": "Trojan:Win32/Wacatac.B!ml",
                "threat_id": "2147728000",
                "action_success": True,
                "still_active": False,
            }
        ],
        "threats_read": True,
        "firewall": [
            {"name": "Domain", "enabled": True},
            {"name": "Private", "enabled": True},
            {"name": "Public", "enabled": False},
        ],
        "av_products": [],
    }


def dry_run() -> None:
    setup_console()
    banner()
    say()
    say("=== 화면 예시 모드 (--dry-run) ===")
    say("실제 검사는 하지 않아. 윈도우에서 보게 될 화면만 순서대로 보여 줄게.")
    say("이 모드는 리눅스·맥에서도 돌아가서, 문구와 형식을 미리 검토할 수 있어.")

    rule("예시 1. 메뉴")
    show_menu(admin_user=True)
    say()
    say("(관리자 권한이 없을 때는 1·2·3·5번 자리에 아래 안내가 먼저 나와.)")
    admin_short_note()

    rule("예시 2. 상태 점검 — 문제가 없을 때")
    render_status(_dry_status_ok())

    rule("예시 3. 상태 점검 — 챙길 게 있을 때")
    render_status(_dry_status_issues())

    rule("예시 4. 상태를 읽지 못했을 때")
    render_status_unavailable("Get-MpComputerStatus: 서비스가 실행되고 있지 않습니다. (0x800106BA)")

    rule("예시 5. 빠른 검사 — 진행 안내와 결과")
    say("지금부터 빠른 검사를 돌릴게. 보통 2~10분 걸려.")
    say("검사 중에는 이 창을 닫지 말고 기다려 줘. 멈추고 싶으면 Ctrl+C를 눌러도 돼.")
    say("  ... 아직 하는 중이야 (1분 0초 지났어)")
    render_scan_result("빠른 검사", 0, 192, [], True)

    rule("예시 6. 폴더 검사 — 걸렸지만 디펜더가 조치했을 때")
    now = datetime.now()
    render_scan_result(
        "폴더 검사 ('내려받은 파일')",
        0,
        74,
        [{
            "time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "name": "Trojan:Win32/Wacatac.B!ml",
            "threat_id": "2147728000",
            "action_success": True,
            "still_active": False,
        }],
        True,
    )

    rule("예시 7. 검사 — 네 확인이 필요할 때 (종료 코드 2)")
    render_scan_result(
        "전체 검사",
        2,
        5401,
        [{
            "time": now.strftime("%Y-%m-%d %H:%M:%S"),
            "name": "PUA:Win32/Puassistant",
            "threat_id": "2147729000",
            "action_success": False,
            "still_active": True,
        }],
        True,
    )

    rule("예시 8. 검사를 못 돌렸을 때 (관리자 권한 없음)")
    render_scan_result("빠른 검사", 0x80070005, 2, [], False)

    rule("예시 9. 검사 도구를 찾지 못했을 때")
    mp_not_found_text()

    rule("예시 10. 윈도우가 아닐 때")
    not_windows_text()

    rule("예시 11. 끝인사")
    farewell()

    say()
    say("여기까지가 예시야. 실제 동작은 윈도우 노트북에서 확인해 줘.")


# ─────────────────────────────────────────────────────────────
# 시작점
# ─────────────────────────────────────────────────────────────

def main(argv=None) -> int:
    setup_console()

    if sys.version_info < (3, 10):
        say("파이썬 3.10 이상이 필요해. 지금은 {}이야.".format(sys.version.split()[0]))
        say("python.org에서 새 파이썬을 받아 설치해 줘.")
        return 1

    args = build_parser().parse_args(argv)

    if args.version:
        say("{} v{}".format(APP_NAME, VERSION))
        return 0

    if args.dry_run:
        dry_run()
        return 0

    greet()

    if not IS_WINDOWS:
        not_windows_text()
        return 4

    admin_user = is_admin()
    has_action = bool(args.quick or args.full or args.folder is not None or args.status or args.update)
    if not admin_user and not has_action:
        admin_short_note()

    if has_action:
        return run_cli(args, admin_user)

    menu_loop(admin_user)
    if not args.no_pause:
        wait_before_close()
    return 0


if __name__ == "__main__":
    exit_code = 0
    try:
        exit_code = main()
    except KeyboardInterrupt:
        say()
        say("알겠어, 여기서 멈출게. 필요하면 다시 불러 줘.")
        exit_code = 130

    # 출력을 파이프로 넘기다가 상대가 먼저 닫은 경우(| head 같은 것),
    # 파이썬이 종료할 때 오류 메시지를 찍지 않도록 조용히 정리한다.
    try:
        sys.stdout.flush()
    except BrokenPipeError:
        try:
            os.dup2(os.open(os.devnull, os.O_WRONLY), sys.stdout.fileno())
        except Exception:
            pass
        exit_code = 0
    sys.exit(exit_code)
